const db = require('../db.connection');



const createTable = async () => {
    return new Promise((res)=>{
        db.query("CREATE TABLE posts (id INT AUTO_INCREMENT PRIMARY KEY, name VARCHAR(255), age INT(3), qulification VARCHAR(255))", (err, rows) => {
            if (err) {
                console.log("error", err);
            }
            return res (rows);
        })
    })
};


const createUser = async (payload) => {
    return new Promise((res)=>{
        db.query("insert into posts values(null,'"+payload.name+"',"+payload.age+",'"+payload.qulification+"')", (err, rows) => {
            if (err) {
                console.log("error", err);
            }
            return res (rows);
        })
    })
};


const getUserId = async (id) => {
    return new Promise((res)=>{
        db.query('select * from posts where id=?',[id],(err,rows)=>{
            if (err) {
                console.log("error", err);
            }
            return res (rows);
        })
    })
};

const getAllUsers = async () => {
    return new Promise((res)=>{
        db.query('select * from posts',(err,rows)=>{
            if (err) {
                console.log("error", err);
            }
            return res (rows);
        })
    })
};

const updateUser = async (payload,id) => {
    return new Promise((res)=>{
        db.query("update posts set name='"+payload.name+"',age="+payload.age+",qulification='"+payload.qulification+"' where id=?",[id],(err,rows)=>{
            if (err) {
                console.log("error", err);
            }
            return res (rows);
        })
    })
};


const deleteUser = async (id) => {
    return new Promise((res)=>{
        db.query('Delete from posts where id=?',[id],(err,rows)=>{
            if (err) {
                console.log("error", err);
            }
            return res (rows);
        })
    })
};

module.exports = {
    createTable,
    createUser,
    getUserId,
    getAllUsers,
    updateUser,
    deleteUser,
};
