const userService = require('../services/user.service');

const createTable =   async (req, res) => {
   const payload = {
        name:req.body.name,
        age:req.body.age,
        qulification:req.body.qulification,

    }

    const user = await userService.createTable(payload);

    res.send("table created sucessfully ");
};

const createUser =   async (req, res) => {
    const payload = {
         name:req.body.name,
         age:req.body.age,
         qulification:req.body.qulification,
 
     }
 
     const user = await userService.createUser(payload);
 
     res.send(user);
 };


 const getUserId = async (req,res)=>{
     const user = await userService.getUserId(req.params.id);
     res.send(user);
 }


 const getAllUsers = async (req,res)=>{
     const user = await userService.getAllUsers();
     res.send(user);
 }
 const updateUser =   async (req, res) => {
    const payload = {
         name:req.body.name,
         age:req.body.age,
         qulification:req.body.qulification,
 
     }
    const id = req.params.id;
     const user = await userService.updateUser(payload,id);
 
     res.send(user);
 };



const deleteUser = async (req, res) => {
  const user = await userService.deleteUser(req.params.id);
  res.send(user);
};

  module.exports = {
    createTable,
    createUser,
    getUserId,
    updateUser,
    deleteUser,
    getAllUsers,
    
  }